
#! /usr/bin/env bash
export HADOOP_PREFIX=/usr/hdp/current/hadoop-client
export HADOOP_CONF_DIR=/usr/hdp/current/hadoop-client/conf
export JAVA_HOME=/usr/local/cloud/java/jdk1.8.0_65
export ZOOKEEPER_HOME=/usr/hdp/current/zookeeper-client
export ACCUMULO_LOG_DIR=/var/log/accumulo
export ACCUMULO_CONF_DIR=/usr/hdp/current/accumulo-client/conf
export ACCUMULO_TSERVER_OPTS="-Xmx1536m -Xms1536m"
export ACCUMULO_MASTER_OPTS="-Xmx1024m -Xms1024m"
export ACCUMULO_MONITOR_OPTS="-Xmx1024m -Xms1024m"
export ACCUMULO_GC_OPTS="-Xmx256m -Xms256m"
export ACCUMULO_GENERAL_OPTS="-XX:+UseConcMarkSweepGC -XX:CMSInitiatingOccupancyFraction=75 -Djava.net.preferIPv4Stack=true ${ACCUMULO_GENERAL_OPTS}"
export ACCUMULO_OTHER_OPTS="-Xmx1024m -Xms1024m ${ACCUMULO_OTHER_OPTS}"
# what do when the JVM runs out of heap memory
export ACCUMULO_KILL_CMD='kill -9 %p'